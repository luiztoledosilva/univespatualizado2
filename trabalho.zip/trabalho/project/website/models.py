from django.db import models

# Create your models here.

class Empresa(models.Model):
    cnpj = models.CharField(unique=True, max_length=14)
    nome=models.CharField(max_length=100)
    seguimento=models.CharField(max_length=50)
    telefone=models.IntegerField


class Projeto(models.Model):
    nome_projeto=models.CharField(max_length=100)
    tipo = models.CharField(max_length=100)
    descricao = models.CharField(unique=True, max_length=1000)
    data_inicio=models.DateField
    data_fim=models.DateField
    empresa_contratada=models.CharField(max_length=100)

    def __str__(self):
        return self.cnpj
        return self.empresa_contratada