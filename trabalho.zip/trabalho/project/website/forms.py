from django import forms

from website.models import Empresa
from website.models  import Projeto

class EmpresaForm(forms.ModelForm):

    class Meta:
        model = Empresa
        fields = '__all__'

        model = Projeto
        fields = "__all__"