from django.views.generic import ListView

from website.models import Empresa
from website.models import Projeto

class CadastroList(ListView):

    model = Empresa
    queryset = Empresa.object.all()

    model = Projeto
    queryset = Projeto.All
